let currentTabIndex = 0;

// Function to load links from storage and open them in new tabs or reload existing ones
function loadLinks() {
  chrome.storage.local.get("links", (result) => {
    const links = result.links || [];
    if (links.length === 0) {
      console.log("No links found in storage.");
      return;
    }

    // Open each link or reload if it's already open
    links.forEach((linkObj) => {
      chrome.tabs.query({}, (tabs) => {
        const existingTab = tabs.find((tab) => tab.url === linkObj.link);
        if (existingTab) {
          // If the tab is already open, reload it
          chrome.tabs.reload(existingTab.id);
        } else {
          // Otherwise, create a new tab
          chrome.tabs.create({ url: linkObj.link });
        }
      });
    });
  });
}

function switchTabs() {
  chrome.storage.local.get(['links'], (result) => {
    const links = result.links || [];

    if (links.length > 0) {
      const firstLink = links[currentTabIndex].link; // Access the 'link' property of the first object

      chrome.tabs.query({}, (tabs) => {
        const tabToSwitch = tabs.find((tab) => tab.url === firstLink);

        if (tabToSwitch) {
          chrome.tabs.update(tabToSwitch.id, { active: true });
        } else {
          chrome.tabs.create({ url: firstLink });
        }
      });
    }
    if (currentTabIndex === links.length - 1) {
      currentTabIndex = 0;
    } else {
      currentTabIndex += 1;
    }
  });
}

function scrollFrame(tabId) {
  scrollInterval = setInterval(() => {
    chrome.scripting.executeScript({
      target: { tabId },
      function: () => {
        const frame = document.querySelector('.ly-lineWrapper');
        if (frame) {
          const totalHeight = frame.scrollHeight;
          const currentPosition = frame.scrollTop + frame.clientHeight;
          const scrollStep = 550;

          // totalHeight is the height of the frame which is 3083px
          // frame.clientHeight is the height from the top to our frame which is 404px
          // frame.scrollTop is the height to which we have scrolled in the frame which is dynamic
          if (currentPosition + scrollStep < totalHeight) {
            frame.scrollBy({
              top: scrollStep,
              left: 0,
              behavior: 'smooth'
            });
          } else {
            frame.scrollTo({
              top: 0,
              left: 0,
              behavior: 'smooth'
            });
          }
        }
      }
    });
  }, 20000); // Scroll every 20 seconds
}


function startScrolling() {
  
}


function stopScrolling() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.sendMessage(tabs.id, { action: "stopScroll" });
    }
  });
}

// Message listener for actions from popup.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "loadTabs") {
    loadLinks();
  } else if (message.action === "switchTab") {
    switchTabs();
  } else if (message.action === "start") {
    startScrolling();
  } else if (message.action === "stop") {
    stopScrolling();
  }
});