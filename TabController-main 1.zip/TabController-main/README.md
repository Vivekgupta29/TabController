A chrome extension to control the browser tabs and pages
