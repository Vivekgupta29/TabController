chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startScroll") {
    // Retrieve the scroll settings from chrome.storage
    chrome.storage.local.get(['links', 'scrollPixels', 'intervalTime'], (result) => {
      const links = result.links || [];
      const scrollPixels = result.scrollPixels || 500; // Default scroll amount
      const intervalTime = result.intervalTime || 1000; // Default delay

      // Find the link object that matches the current tab's URL
      const currentUrl = window.location.href;
      const linkObj = links.find(link => link.link === currentUrl);

      if (linkObj) {
        const scrollClass = linkObj.className; // Get the class name for the current URL

        console.log("Scroll Class:", scrollClass, "Scroll Pixels:", scrollPixels, "Interval Time:", intervalTime);

        const scrollElement = document.querySelector(scrollClass);
        if (scrollElement) {
          scrollInterval = setInterval(() => {
            scrollElement.scrollBy({ top: scrollPixels, behavior: 'smooth' });
          }, intervalTime);
        } else {
          console.error("Scroll element not found:", scrollClass);
        }
      } else {
        console.error("No matching link found for the current URL.");
      }
    });
  } else if (message.action === "stopScroll") {
    clearInterval(scrollInterval);
    console.log("Scrolling stopped.");
  }
});
